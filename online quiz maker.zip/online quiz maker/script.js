const questions = [
    {
        question: "What does HTML stand for?",
        answers: [
            { text: "HyperText Markup Language", correct: true },
            { text: "HyperText Machine Language", correct: false },
            { text: "HyperText Marking Language", correct: false },
            { text: "HighText Markup Language", correct: false },
        ]
    },
    {
        question: "The HTML tag that specifies a CSS style embedded in an element is called ____?",
        answers: [
            { text: "Design", correct: false },
            { text: "style", correct: true },
            { text: "modify", correct: false },
            { text: "Define", correct: false },
        ]
    },
    {
        question: "HTML was first proposed in ___.?",
        answers: [
            { text: "1980", correct: false},
            { text: "1990", correct: true },
            { text: "1995", correct: false },
            { text: "2000", correct: false },
        ]
    },
    {
        question: "Who is the main author of the HTML?",
        answers: [
            { text: " Brendan Eich", correct: false },
            { text: "Tim Berners-Lee", correct: true },
            { text: " Web developer", correct: false },
            { text: "Google Inc", correct: false },
        ]
    },
    {
        question: "Which property is used to change the background color?",
        answers: [
            { text: "color", correct: false },
            { text: "background-color", correct: true },
            { text: "bgcolor", correct: false },
            { text: "background", correct: false },
        ]
    },
    {
        question: "Which CSS property is used to change the text color of an element?",
        answers: [
            { text: "text-color", correct: false },
            { text: "font-color", correct: false },
            { text: "color", correct: true },
            { text: "text-style", correct: false },
        ]
    },
    {
        question: "Which CSS property is used to change the font of an element?",
        answers: [
            { text: "font-weight", correct: false },
            { text: "font-style", correct: false },
            { text: "font-family", correct: true },
            { text: "font-size", correct: false },
        ]
    },
    {
        question: "HTML is considered as ______ ?",
        answers: [
            { text: " Programming language", correct: false },
            { text: "OOP language", correct: false },
            { text: "High level language", correct: false },
            { text: "Markup language", correct: true },
        ]
    },
    {
        question: "Which property is used to change the font size of an element?",
        answers: [
            { text: "text-size", correct: false },
            { text: "font-size", correct: true },
            { text: "font-style", correct: false },
            { text: "text-style", correct: false },
        ]
    },
    {
        question: "Which CSS property is used to create space between the element's border and its content?",
        answers: [
            { text: "margin", correct: false },
            { text: "padding", correct: true },
            { text: "border", correct: false },
            { text: "spacing", correct: false },
        ]
    }
];


const questionElement = document.getElementById("question");
const answerButtons = document.getElementById("answer-buttons");
const nextButton = document.getElementById("next-btn");

let currentQuestionIndex = 0;
let score = 0;


function startQuiz() {
    currentQuestionIndex = 0;
    score = 0;
    nextButton.innerHTML = "Next";
    nextButton.style.display = "none";
    showQuestion();
}

function showQuestion() {
    resetState();
    let currentQuestion = questions[currentQuestionIndex];
    let questionNo = currentQuestionIndex + 1;
    questionElement.innerHTML = questionNo + ". " + currentQuestion.question;

    currentQuestion.answers.forEach(answer => {
        const button = document.createElement("button");
        button.innerHTML = answer.text;
        button.classList.add("btn");
        if (answer.correct) {
            button.dataset.correct = answer.correct;
        }
        button.addEventListener("click", selectAnswer);
        answerButtons.appendChild(button);
    });
}

function resetState() {
    nextButton.style.display = "none";
    while (answerButtons.firstChild) {
        answerButtons.removeChild(answerButtons.firstChild);
    }
}

function selectAnswer(e) {
    const selectedButton = e.target;
    const isCorrect = selectedButton.dataset.correct === "true";
    if (isCorrect) {
        score++;
    }
    Array.from(answerButtons.children).forEach(button => {
        setStatusClass(button, button.dataset.correct === "true");
    });
    nextButton.style.display = "block";
}

function setStatusClass(element, correct) {
    clearStatusClass(element);
    if (correct) {
        element.classList.add("correct");
    } else {
        element.classList.add("incorrect");
    }
}

function clearStatusClass(element) {
    element.classList.remove("correct");
    element.classList.remove("incorrect");
}

nextButton.addEventListener("click", () => {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        showQuestion();
    } else {
        showScore();
    }
});

function showScore() {
    resetState();
    questionElement.innerHTML = `You scored ${score} out of ${questions.length}!`;
    alert("Congratulation you have attend the quiz")
    nextButton.innerHTML = "Restart";
    nextButton.style.display = "block";
    nextButton.removeEventListener("click", showQuestion);
    nextButton.addEventListener("click", startQuiz);
}

startQuiz();
 